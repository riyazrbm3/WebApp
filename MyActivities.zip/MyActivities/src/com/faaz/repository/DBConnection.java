package com.faaz.repository;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	
	  public static Connection getConnection(){  
	        Connection con=null;  
	        try{  
	            Class.forName("oracle.jdbc.driver.OracleDriver");  
	            con=DriverManager.getConnection("jdbc:oracle:thin:@sithik.development.com:1521:faazil","faazil","faazil");  
	        }catch(Exception e){System.out.println(e);}  
	        return con;  
	    }  

}
