package com.faaz.repository;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.text.StyledEditorKit.ItalicAction;

import com.faaz.domain.ActivLink;
import com.faaz.domain.Activity;
import com.faaz.domain.UsersLog;

public class Activities {

	public boolean isUserExist(String loginId,String password) throws SQLException {
		boolean result = false;
		System.out.println();
		Connection con = DBConnection.getConnection();
		String query = "select * from userslog where loginid = '"+loginId+"'and pasword = '"+password+"'";
		System.out.println("Query:"+query);		
		PreparedStatement ps=con.prepareStatement("select * from userslog where loginid='"+loginId+"' and pasword='"+password+"'"); 
		ResultSet rs=ps.executeQuery();  
		while(rs.next()) {
			System.out.println("User Name:"+rs.getString("loginid"));
			System.out.println("Password:"+rs.getString("pasword"));
			result = true;
		}
		ps.close();
		con.close();
		return result;  
	}
	
	public boolean isUserExist(String UserName) throws SQLException {
		boolean result = false;
		Connection con = DBConnection.getConnection();
		PreparedStatement ps=con.prepareStatement("select * from userslog where UserName='"+UserName+"'");  
		ResultSet rs=ps.executeQuery();  
		while(rs.next()) {
			result = true;
		}
		con.close();
		return result;  
	}
	
	public UsersLog getUserDetails(String loginId) throws SQLException {
		UsersLog u = new UsersLog();
		Connection con = DBConnection.getConnection();
		PreparedStatement ps=con.prepareStatement("select * from userslog where loginid='"+loginId+"'");  
		ResultSet rs=ps.executeQuery();  
		while(rs.next()) {
			String tloginId = rs.getString("loginid");
			String userName = rs.getString("username");
			String password = rs.getString("pasword");
			System.out.println("Login ID:"+tloginId);
			System.out.println("User Name:"+userName);
			System.out.println("Password:"+password);
			u.setLoginId(tloginId);
			u.setUserName(userName);
		}
		con.close();
		return u;
	}
	
	
	public List<Activity> getActivDetails(String userId) throws SQLException {
		List<Activity> activities = new ArrayList<>();
		Connection con = DBConnection.getConnection();
		PreparedStatement ps=con.prepareStatement("select * from activity where userid='"+userId+"'");  
		ResultSet rs=ps.executeQuery();  
		while(rs.next()) {
			Activity a = new Activity();
			int activeId= rs.getInt("activeid");
			//System.out.println("Active ID:"+activeId);
			//System.out.println("User Id:"+userId);
			a.setActiveId(activeId);
			a.setUserId(userId);
			activities.add(a);
		}
		con.close();
		return activities;
	}	

	public List<ActivLink> getActiveLinks(int activeID) throws SQLException {
			List<ActivLink> activities = new ArrayList<>();
			Connection con = DBConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from activlink where activeid="+activeID);  
			ResultSet rs=ps.executeQuery();  
			while(rs.next()) {
				ActivLink a = new ActivLink();
				int activeId= rs.getInt("activeid");
				String discussion = rs.getString("discussion");
				String status = rs.getString("status");
				int hoursSpend = rs.getInt("hoursspend");
				Timestamp logDate = rs.getTimestamp("logdate");
				//System.out.println();
				a.setDisscussion(discussion);
				a.setStatus(status);
				a.setHoursSpend(hoursSpend);
				a.setLogDate(logDate);
				activities.add(a);
			}
			con.close();
			return activities;
	}
	
	public void insertNewRecord(List<ActivLink> data) throws SQLException {
		Connection con = DBConnection.getConnection();
		for (Iterator iterator = data.iterator(); iterator.hasNext();) {
			ActivLink activLink = (ActivLink) iterator.next();
			String query = "INSERT INTO activlink(IDA2A2,DISCUSSION,STATUS,HOURSSPEND,LOGDATE,ACTIVEID) VALUES(activities_seq.nextval,'"+activLink.getDisscussion()+"','"+activLink.getStatus()+"',"+activLink.getHoursSpend()+",?,"+activLink.getActivity().getActiveId()+")";
			System.out.println("Query:"+query);
			PreparedStatement ps=con.prepareStatement(query);  
			ps.setDate(1, new Date(new java.util.Date().getTime()));
			boolean result = ps.execute();
			ps.close();
			System.out.println("Record inserted successfully:"+result);
			
		}
		con.close();
	}
	
	
	
	
	public void DeleteRecord(List<ActivLink> data) throws SQLException{
		Connection con = DBConnection.getConnection();
		for (Iterator<ActivLink> iterator =data.iterator(); iterator.hasNext();) {
			ActivLink activLink =(ActivLink) iterator.next();
			String query ="Delete from ActivLink"+" WHERE activeID=1020";
			System.out.println("Query:"+query);
			PreparedStatement ps=con.prepareStatement(query);
			ps.execute();
			ps.close();
			System.out.println("Record Deleted successfully");
			
		}
		con.close();
	}
	
	public void insertNewUsersRecord (UsersLog usersLog)  throws SQLException{
	    Connection con = DBConnection.getConnection();  
	String query ="INSERT INTO Userslog(LOGINID,USERNAME,PASWORD) VALUES('"+usersLog.getLoginId()+"','"+usersLog.getUserName()+"','"+usersLog.getPasword()+"')";
	System.out.println("Query:"+query);
	PreparedStatement ps=con.prepareStatement(query);
	ps.execute();
	ps.close();
	con.close();
	}
	
	public boolean insertNewPasswordData (String loginId,String currentPassword,String newPassword) throws SQLException {
		boolean result = false;
		Connection con = DBConnection.getConnection();
		String query = "Select loginId, username, pasword from userslog WHERE loginid ='"+loginId+"' and pasword ='"+currentPassword+"'";
		System.out.println("Query:"+query);
		PreparedStatement ps=con.prepareStatement(query);
		ResultSet rs=ps.executeQuery();  
		while(rs.next()) {
			result = true;
		String tloginId= rs.getString("loginId");
		String username = rs.getString("username");
		String pasword = rs.getString("pasword");
		System.out.println("loginId:"+tloginId);
		System.out.println("username:"+username);
		System.out.println("password:"+pasword);
		}
		
		if(result==true) {
		
			String query1 = "UPDATE userslog set pasword='"+newPassword+"' where loginid='"+loginId+"'";
			System.out.println("Query:"+query1);
			PreparedStatement ps1=con.prepareStatement(query1);
			boolean rs1=ps1.execute();
			ps1.close(); 
			System.out.println("password updated :"+rs1);
		
		}
		
		ps.close();
		con.close();
		// 1. Database query : Check whether currentPassword is valid for the given loginID
		// 2. Update newPassword (Update SQL query : update new Password 	
		
		return result;
	}
	
}
	
