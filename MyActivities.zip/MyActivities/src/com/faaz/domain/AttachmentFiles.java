package com.faaz.domain;

public class AttachmentFiles {
	
	private int attachmentFile;
	
	private String fileName;
	
	private int fileSize;
	
	private int activLinkId;

	public int getAttachmentFile() {
		return attachmentFile;
	}

	public void setAttachmentFile(int attachmentFile) {
		this.attachmentFile = attachmentFile;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getFileSize() {
		return fileSize;
	}

	public void setFileSize(int fileSize) {
		this.fileSize = fileSize;
	}

	public int getActivLinkId() {
		return activLinkId;
	}

	public void setActivLinkId(int activLinkId) {
		this.activLinkId = activLinkId;
	}
	
	

}
