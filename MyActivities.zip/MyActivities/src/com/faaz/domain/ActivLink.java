package com.faaz.domain;

import java.sql.Timestamp;

public class ActivLink {
	
	private long ida2a2;
	
	private String disscussion;
	
	private String status;
	
	private int hoursSpend;
	
	private Timestamp logDate;
	
	private Activity activity;

	public long getIda2a2() {
		return ida2a2;
	}

	public void setIda2a2(long ida2a2) {
		this.ida2a2 = ida2a2;
	}

	public String getDisscussion() {
		return disscussion;
	}

	public void setDisscussion(String disscussion) {
		this.disscussion = disscussion;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getHoursSpend() {
		return hoursSpend;
	}

	public void setHoursSpend(int hoursSpend) {
		this.hoursSpend = hoursSpend;
	}

	public Timestamp getLogDate() {
		return logDate;
	}

	public void setLogDate(Timestamp logDate) {
		this.logDate = logDate;
	}

	public Activity getActivity() {
		return activity;
	}

	public void setActivity(Activity activity) {
		this.activity = activity;
	}
	
	


}
