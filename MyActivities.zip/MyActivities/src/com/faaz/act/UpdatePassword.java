package com.faaz.act;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.faaz.domain.UsersLog;
import com.faaz.repository.Activities;

/**
 * Servlet implementation class UpdatePassword
 */
@WebServlet("/UpdatePassword")
public class UpdatePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdatePassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		System.out.println("DoPost is getting called");
		
		String CurrentPassword = request.getParameter("CurrentPassword");
		String NewPassword = request.getParameter("Newpassword");
		String ConformPassword = request.getParameter("conformPassword");
		System.out.println("currentPassword:"+CurrentPassword);
		System.out.println("newPassword:"+NewPassword);
		System.out.println("conformPassword:"+ConformPassword);
		String username =request.getParameter("uname");
		System.out.println("uname:"+username);
		Activities activities = new Activities();
		try {
			boolean result = activities.insertNewPasswordData(username, CurrentPassword, NewPassword);
			if(result==false) {
				System.out.println("Invalid password");
				response.getWriter().write("Invalid");
			} else {
				System.out.println("Valid Password");
				response.getWriter().write("Valid");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	
	}

}
