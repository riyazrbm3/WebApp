package com.faaz.act;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.faaz.repository.Activities;

/**
 * Servlet implementation class LoginPage
 */
@WebServlet("/LoginPage")
public class LoginPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("doGet: UserName:"+request.getParameter("uname"));
		System.out.println("Password:"+request.getParameter("pwd"));
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("UserName:"+request.getParameter("uname"));
		System.out.println("Password:"+request.getParameter("pwd"));
		String userName = request.getParameter("uname");
		String pasword = request.getParameter("pwd");
		
		
		Activities a = new Activities();
		boolean result = false;
		try {
			result = a.isUserExist(userName,pasword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.println("Result is user exist:"+result);
		if(result==true) {
			
			 PrintWriter out = response.getWriter();  
	         response.setContentType("text/html");
	         out.println("<html>Activitices Table <body>"); 
			
		} else {
			
			RequestDispatcher dispatcher = getServletContext()
				      .getRequestDispatcher("/LoginFailed.jsp");
				    dispatcher.forward(request, response);
		}
		
	}

}

