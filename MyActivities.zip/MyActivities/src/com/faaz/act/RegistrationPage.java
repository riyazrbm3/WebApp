package com.faaz.act;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.User;

import com.faaz.domain.UsersLog;
import com.faaz.repository.Activities;

/**
 * Servlet implementation class RegistrationPage
 */
@WebServlet("/RegistrationPage")
public class RegistrationPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//
		String username =request.getParameter("uid");
		System.out.println("UserName:"+username);
		
		System.out.println("Data:"+request.getParameter("uid"));
		response.getWriter().write("We have received input from JSP");
//	
//        String username =request.getParameter("uid");
//        
//        System.out.println("UserName:"+username);
//      Activities activities = new Activities();
//		boolean result = false;
//		try {
//			result = activities.isUserExist(username);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		if(result==false) {
//			System.out.println("<font color=red>");
//			System.out.println("UserName is not available");
//			response.getWriter().write("Not Available");
//		} else {
//		System.out.println("<font color=green>");
//		System.out.println("UserName  available");
//		response.getWriter().write("Available");
//		}
//		
		
		
		
	}}	
		

//		System.out.println("LOGINID:"+request.getParameter("loginId"));
//		System.out.println("USERNAME:"+request.getParameter("userName"));
//		System.out.println("PASSWORD:"+request.getParameter("password"));
//		UsersLog a = new UsersLog();
//		String loginId= request.getParameter("loginId");
//		a.setLoginId(loginId);
//		String pasword = request.getParameter("userName");
//		a.setPasword(pasword );
//		String userName = request.getParameter("password");
//		a.setUserName(userName );
//		Activities activities = new Activities();
//		try {
//			activities.insertNewUsersRecord(a);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
		//}
	//}
	

