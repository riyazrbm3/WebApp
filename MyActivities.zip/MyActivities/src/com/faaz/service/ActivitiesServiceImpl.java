package com.faaz.service;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.faaz.domain.ActivLink;
import com.faaz.domain.Activity;
import com.faaz.repository.Activities;

public class ActivitiesServiceImpl {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		Activities a = new Activities();
		boolean result = a.isUserExist("fayaz@gmail.com", "654321");
        System.out.println("Result is user exist:"+result);
        
        if(result == true) {
        	a.getUserDetails("fayaz@gmail.com");
        	List<Activity> activty = a.getActivDetails("fayaz@gmail.com");
        	System.out.println(activty.toString());
        	for (Iterator<Activity> iterator = activty.iterator(); iterator.hasNext();) {
				Activity activity = (Activity) iterator.next();
				System.out.println("Activity ID:"+activity.getActiveId());
				
//				List<ActivLink> activLinks = a.getActiveLinks(activity.getActiveId());
//				for (Iterator<ActivLink> iterator1= activLinks.iterator();iterator1.hasNext();) {
//					ActivLink activLink =(ActivLink) iterator1.next();
//					System.out.println("Activity ID:"+activLink.getDisscussion());
//					System.out.println("Activity ID:"+activLink.getStatus());
//					System.out.println("Activity ID:"+activLink.getHoursSpend());
//					System.out.println("Activity ID:"+activLink.getLogDate());
//					
//				}
				
				if(activity.getActiveId()==1020) {
					List<ActivLink> activLinks = new ArrayList<ActivLink>();
					ActivLink activLink = new ActivLink();
					activLink.setDisscussion("Updating from Java");
					activLink.setHoursSpend(1);
					activLink.setStatus("In Progress");
					Date d = new Date();
					System.out.println(d.toString());
					Timestamp t = new Timestamp(d.getTime());
					activLink.setLogDate(t);
					activLink.setActivity(activity);
					activLinks.add(activLink);
					
					activLink = new ActivLink();
					activLink.setDisscussion("Updating from Java 2");
					activLink.setHoursSpend(1);
					activLink.setStatus("In Progress");
					activLink.setLogDate(t);
					activLink.setActivity(activity);
					activLinks.add(activLink);
					
					activLink = new ActivLink();
					activLink.setStatus("progress is complete");
					activLink.setDisscussion("Updating from Java 3");
					activLink.setHoursSpend(1);
					activLink.setLogDate(t);
					activLink.setActivity(activity);
					activLinks.add(activLink);
					a.insertNewRecord(activLinks);
				
				}
				if(activity.getActiveId()==1020) {
				String activeId = "delete from ActivLink " +"where ActiveID=1020";
		          System.out.println("Record is deleted from the table successfully..");
        }
	}
 }
	
}
}
